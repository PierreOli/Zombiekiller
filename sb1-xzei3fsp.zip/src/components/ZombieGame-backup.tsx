import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Target, Crosshair, Heart, Skull } from 'lucide-react';

interface Position {
  x: number;
  y: number;
}

interface Zombie {
  id: number;
  x: number;
  y: number;
  speed: number;
  health: number;
  maxHealth: number;
  type: 'normal' | 'fast' | 'tank';
  directionX: number;
  directionY: number;
}

interface Bullet {
  id: number;
  x: number;
  y: number;
  directionX: number;
  directionY: number;
  speed: number;
  damage: number;
}

interface Weapon {
  name: string;
  damage: number;
  ammo: number;
  maxAmmo: number;
  fireRate: number;
  icon: string;
}

const GAME_WIDTH = window.innerWidth;
const GAME_HEIGHT = window.innerHeight - 80;

export function ZombieGameBackup() {
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameOver'>('menu');
  const [zombies, setZombies] = useState<Zombie[]>([]);
  const [bullets, setBullets] = useState<Bullet[]>([]);
  const [score, setScore] = useState(0);
  const [wave, setWave] = useState(1);
  const [health, setHealth] = useState(100);
  const [combo, setCombo] = useState(0);
  const [lastKillTime, setLastKillTime] = useState(0);
  const [playerPos] = useState<Position>({ x: GAME_WIDTH / 2, y: GAME_HEIGHT / 2 });
  const [mousePos, setMousePos] = useState<Position>({ x: 0, y: 0 });
  
  const [weapons] = useState<Weapon[]>([
    { name: 'Pistol', damage: 100, ammo: 50, maxAmmo: 50, fireRate: 300, icon: '🔫' },
    { name: 'Shotgun', damage: 200, ammo: 20, maxAmmo: 20, fireRate: 800, icon: '💥' },
    { name: 'Rifle', damage: 150, ammo: 100, maxAmmo: 100, fireRate: 150, icon: '🔫' }
  ]);
  
  const [currentWeapon, setCurrentWeapon] = useState(0);
  const [lastFireTime, setLastFireTime] = useState(0);
  
  const gameRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number>();
  const zombieSpawnRef = useRef<number>();
  const lastFrameTime = useRef<number>(0);

  const spawnZombie = useCallback(() => {
    const side = Math.floor(Math.random() * 4);
    let x, y;
    
    switch (side) {
      case 0: // Top
        x = Math.random() * GAME_WIDTH;
        y = -50;
        break;
      case 1: // Right
        x = GAME_WIDTH + 50;
        y = Math.random() * GAME_HEIGHT;
        break;
      case 2: // Bottom
        x = Math.random() * GAME_WIDTH;
        y = GAME_HEIGHT + 50;
        break;
      default: // Left
        x = -50;
        y = Math.random() * GAME_HEIGHT;
    }

    const types: Zombie['type'][] = ['normal', 'normal', 'fast', 'tank'];
    const type = types[Math.floor(Math.random() * types.length)];
    
    const maxHealth = type === 'tank' ? 200 : type === 'fast' ? 75 : 100;
    const speed = type === 'fast' ? 2 : type === 'tank' ? 0.8 : 1.2;
    
    // Pre-calculate direction
    const distance = Math.sqrt((playerPos.x - x) ** 2 + (playerPos.y - y) ** 2);
    const directionX = (playerPos.x - x) / distance;
    const directionY = (playerPos.y - y) / distance;

    const zombie: Zombie = {
      id: Date.now() + Math.random(),
      x,
      y,
      speed,
      health: maxHealth,
      maxHealth,
      type,
      directionX,
      directionY
    };

    setZombies(prev => [...prev, zombie]);
  }, [playerPos]);

  const fire = useCallback((targetX: number, targetY: number) => {
    const now = Date.now();
    const weapon = weapons[currentWeapon];
    
    if (now - lastFireTime < weapon.fireRate || weapon.ammo <= 0) return;
    
    setLastFireTime(now);
    
    // Decrease ammo
    const newWeapons = [...weapons];
    newWeapons[currentWeapon] = { ...weapon, ammo: weapon.ammo - 1 };
    
    // Pre-calculate bullet direction
    const distance = Math.sqrt((targetX - playerPos.x) ** 2 + (targetY - playerPos.y) ** 2);
    const directionX = (targetX - playerPos.x) / distance;
    const directionY = (targetY - playerPos.y) / distance;

    const bullet: Bullet = {
      id: Date.now(),
      x: playerPos.x,
      y: playerPos.y,
      directionX,
      directionY,
      speed: 15,
      damage: weapon.damage
    };

    setBullets(prev => [...prev, bullet]);
  }, [currentWeapon, weapons, lastFireTime, playerPos]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (gameRef.current) {
      const rect = gameRef.current.getBoundingClientRect();
      setMousePos({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  }, []);

  const handleClick = useCallback((e: React.MouseEvent) => {
    if (gameState !== 'playing') return;
    
    if (gameRef.current) {
      const rect = gameRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      fire(x, y);
    }
  }, [gameState, fire]);

  const gameLoop = useCallback((currentTime: number) => {
    if (gameState !== 'playing') return;

    const deltaTime = currentTime - lastFrameTime.current;
    lastFrameTime.current = currentTime;
    
    // Limit to 60 FPS
    if (deltaTime < 16) {
      animationRef.current = requestAnimationFrame(gameLoop);
      return;
    }

    // Move zombies (batch update)
    setZombies(prev => {
      const newZombies: Zombie[] = [];
      let playerHit = false;
      
      for (const zombie of prev) {
        // Move zombie
        const newX = zombie.x + zombie.directionX * zombie.speed;
        const newY = zombie.y + zombie.directionY * zombie.speed;
        
        // Check if zombie reached player
        const distance = Math.sqrt((newX - playerPos.x) ** 2 + (newY - playerPos.y) ** 2);
        
        if (distance < 50) {
          if (!playerHit) {
            playerHit = true;
            const damage = zombie.type === 'tank' ? 15 : zombie.type === 'fast' ? 8 : 10;
            setHealth(prev => Math.max(0, prev - damage));
          }
        } else {
          newZombies.push({
            ...zombie,
            x: newX,
            y: newY
          });
        }
      }
      
      return newZombies;
    });

    // Move bullets (batch update)
    setBullets(prev => prev.map(bullet => ({
      ...bullet,
      x: bullet.x + bullet.directionX * bullet.speed,
      y: bullet.y + bullet.directionY * bullet.speed
    })).filter(bullet => 
      bullet.x > -50 && bullet.x < GAME_WIDTH + 50 && 
      bullet.y > -50 && bullet.y < GAME_HEIGHT + 50
    ));

    // Check collisions (optimized)
    setBullets(prevBullets => {
      const remainingBullets: Bullet[] = [];
      const bulletsToRemove = new Set<number>();
      
      setZombies(prevZombies => {
        const newZombies: Zombie[] = [];
        
        for (const zombie of prevZombies) {
          let zombieHit = false;
          
          for (const bullet of prevBullets) {
            if (bulletsToRemove.has(bullet.id) || zombieHit) continue;
            
            const distance = Math.sqrt((bullet.x - zombie.x) ** 2 + (bullet.y - zombie.y) ** 2);
            
            if (distance < 30) {
              bulletsToRemove.add(bullet.id);
              zombieHit = true;
              
              const newHealth = zombie.health - bullet.damage;
              
              if (newHealth <= 0) {
                const now = Date.now();
                const points = zombie.type === 'tank' ? 50 : zombie.type === 'fast' ? 30 : 20;
                
                if (now - lastKillTime < 2000) {
                  setCombo(prev => prev + 1);
                } else {
                  setCombo(1);
                }
                
                setScore(prev => prev + points * Math.max(1, combo));
                setLastKillTime(now);
              } else {
                newZombies.push({ ...zombie, health: newHealth });
              }
              break;
            }
          }
          
          if (!zombieHit) {
            newZombies.push(zombie);
          }
        }
        
        return newZombies;
      });
      
      return prevBullets.filter(bullet => !bulletsToRemove.has(bullet.id));
    });

    animationRef.current = requestAnimationFrame(gameLoop);
  }, [gameState, playerPos, combo, lastKillTime]);

  const startGame = () => {
    setGameState('playing');
    setScore(0);
    setWave(1);
    setHealth(100);
    setCombo(0);
    setZombies([]);
    setBullets([]);
    setCurrentWeapon(0);
    lastFrameTime.current = 0;
  };

  const resetGame = () => {
    setGameState('menu');
    setZombies([]);
    setBullets([]);
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
    if (zombieSpawnRef.current) {
      clearInterval(zombieSpawnRef.current);
    }
  };

  useEffect(() => {
    if (gameState === 'playing') {
      lastFrameTime.current = performance.now();
      animationRef.current = requestAnimationFrame(gameLoop);
      
      zombieSpawnRef.current = setInterval(() => {
        spawnZombie();
      }, Math.max(1500 - wave * 50, 800));
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      if (zombieSpawnRef.current) {
        clearInterval(zombieSpawnRef.current);
      }
    };
  }, [gameState, gameLoop, spawnZombie, wave]);

  useEffect(() => {
    if (health <= 0) {
      setGameState('gameOver');
    }
  }, [health]);

  // Weapon switching
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (gameState !== 'playing') return;
      
      const key = parseInt(e.key);
      if (key >= 1 && key <= weapons.length) {
        setCurrentWeapon(key - 1);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [gameState, weapons.length]);

  if (gameState === 'menu') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-red-900 to-black flex items-center justify-center">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-6xl font-bold text-red-500 tracking-wider uppercase">
              ZOMBIE<span className="text-orange-500">KILLER</span> <span className="text-sm text-gray-400">(BACKUP)</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Version sauvegardée du jeu optimisé
            </p>
          </div>
          
          <div className="space-y-4">
            <button
              onClick={startGame}
              className="px-12 py-4 bg-red-600 hover:bg-red-700 text-white text-xl font-bold rounded-lg 
                       transform hover:scale-105 transition-all duration-200 border-2 border-red-500 
                       shadow-lg shadow-red-500/25"
            >
              <Target className="inline-block mr-3" />
              JOUER VERSION BACKUP
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (gameState === 'gameOver') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-900 via-red-900 to-black flex items-center justify-center">
        <div className="text-center space-y-6">
          <Skull className="mx-auto text-red-500 mb-4" size={80} />
          <h2 className="text-4xl font-bold text-red-500 mb-4">GAME OVER</h2>
          <div className="space-y-2">
            <p className="text-2xl text-white">Score Final: <span className="text-orange-500">{score.toLocaleString()}</span></p>
            <p className="text-xl text-gray-300">Vague: {wave}</p>
            <p className="text-lg text-yellow-400">Meilleur Combo: {combo}</p>
          </div>
          <div className="space-x-4 pt-4">
            <button
              onClick={startGame}
              className="px-8 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg"
            >
              REJOUER
            </button>
            <button
              onClick={resetGame}
              className="px-8 py-3 bg-gray-700 hover:bg-gray-600 text-white font-bold rounded-lg"
            >
              MENU
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* HUD */}
      <div className="bg-gray-900 p-4 flex justify-between items-center border-b-2 border-red-500">
        <div className="flex space-x-6">
          <div className="text-white">
            <span className="text-red-400">Score:</span> {score.toLocaleString()}
          </div>
          <div className="text-white">
            <span className="text-orange-400">Vague:</span> {wave}
          </div>
          <div className="text-white">
            <span className="text-yellow-400">Combo:</span> {combo}x
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Heart className="text-red-500" size={20} />
            <div className="w-24 bg-gray-700 rounded-full h-3">
              <div 
                className="bg-red-500 h-3 rounded-full transition-all duration-300"
                style={{ width: `${health}%` }}
              />
            </div>
            <span className="text-white text-sm">{health}</span>
          </div>
          
          <div className="flex space-x-2">
            {weapons.map((weapon, index) => (
              <div 
                key={index}
                className={`flex items-center space-x-1 px-2 py-1 rounded ${
                  currentWeapon === index ? 'bg-red-600' : 'bg-gray-700'
                }`}
              >
                <span className="text-white text-sm">{index + 1}</span>
                <span>{weapon.icon}</span>
                <span className="text-white text-sm">{weapon.ammo}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Game Area */}
      <div className="flex-1 relative overflow-hidden">
        <div
          ref={gameRef}
          className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 relative cursor-none"
          style={{ width: '100vw', height: 'calc(100vh - 80px)' }}
          onMouseMove={handleMouseMove}
          onClick={handleClick}
        >
          {/* Player */}
          <div
            className="absolute w-16 h-16 bg-blue-500 rounded-full border-4 border-blue-300 shadow-xl flex items-center justify-center"
            style={{
              left: playerPos.x - 32,
              top: playerPos.y - 32,
              zIndex: 10
            }}
          >
            <span className="text-2xl">🎯</span>
          </div>

          {/* Crosshair */}
          <Crosshair
            className="absolute text-red-400 pointer-events-none z-20 drop-shadow-lg"
            style={{
              left: mousePos.x - 16,
              top: mousePos.y - 16
            }}
            size={32}
          />

          {/* Zombies */}
          {zombies.map(zombie => (
            <div
              key={zombie.id}
              className={`absolute rounded-full border-4 shadow-lg flex items-center justify-center ${
                zombie.type === 'fast' 
                  ? 'bg-yellow-600 border-yellow-400 w-12 h-12' 
                  : zombie.type === 'tank'
                  ? 'bg-purple-600 border-purple-400 w-20 h-20'
                  : 'bg-green-600 border-green-400 w-16 h-16'
              }`}
              style={{
                left: zombie.x - (zombie.type === 'tank' ? 40 : zombie.type === 'fast' ? 24 : 32),
                top: zombie.y - (zombie.type === 'tank' ? 40 : zombie.type === 'fast' ? 24 : 32),
                zIndex: 5
              }}
            >
              <span className="text-2xl">
                {zombie.type === 'fast' ? '💨' : zombie.type === 'tank' ? '🛡️' : '🧟'}
              </span>
              
              {/* Health bar */}
              {zombie.health < zombie.maxHealth && (
                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-16 h-2 bg-gray-800 rounded border border-gray-600">
                  <div 
                    className="h-full bg-gradient-to-r from-red-600 to-red-400 rounded"
                    style={{ width: `${(zombie.health / zombie.maxHealth) * 100}%` }}
                  />
                </div>
              )}
            </div>
          ))}

          {/* Bullets */}
          {bullets.map(bullet => (
            <div
              key={bullet.id}
              className="absolute w-3 h-3 bg-yellow-300 rounded-full shadow-lg border border-yellow-500"
              style={{
                left: bullet.x - 6,
                top: bullet.y - 6,
                boxShadow: '0 0 8px #fde047',
                zIndex: 8
              }}
            />
          ))}

          {/* Instructions overlay */}
          {zombies.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="bg-black bg-opacity-70 text-white p-6 rounded-lg text-center">
                <h3 className="text-xl font-bold mb-2">🎯 Prêt à survivre ?</h3>
                <p className="text-sm">Clique pour tirer • Touches 1-2-3 pour changer d'arme</p>
                <p className="text-xs text-gray-300 mt-2">Les zombies arrivent...</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}