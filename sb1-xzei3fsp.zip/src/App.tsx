import React from 'react';
import { ZombieGame } from './components/ZombieGame';

function App() {
  return <ZombieGame />;
}

export default App;